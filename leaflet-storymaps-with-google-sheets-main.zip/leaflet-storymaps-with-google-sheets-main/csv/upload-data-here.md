Option: upload your Google Sheets data in separate CSV files here, as described in https://handsondataviz.org/leaflet-storymaps-with-google-sheets/
